# @aws-crypto/util

Helper functions

## Usage

```
import { convertToBuffer } from '@aws-crypto/util';

const data = "asdf";
const utf8EncodedUint8Array = convertToBuffer(data);
```

## Test

`npm test`
